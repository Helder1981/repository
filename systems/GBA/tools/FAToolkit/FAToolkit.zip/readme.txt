Flash Advance Toolkit (F.A.T.) V8 by Costis

Changes in this version
-----------------------

V8.0

Wow! Has it been a whole year without a new FAT release already?!?! I'm very sorry for the long wait, but I've just been very busy lately. All EEPROM games should be patchable (except a few for which there are IPS patches around). Also, this version supports Removing 00's, Exit Hack patching (thanks Herg!), and IPS patching. I have also implemented an option that places a "-p" in the patched output filename. This option isn't working too well at the moment. To use it, you must make sure that it is checked before you click on the Input Filename text box's Browse button. After you check it, then click on the Browse option and choose an input file to be patched. The filename should also be copied to the Output Filename text box with a -p in the name as well! I will make the -p option much easier to use in future versions! I'm releasing this version quickly before the new year, so expect there to be a new release within a month or two containing zip file support that I promised before and maybe even a new GUI. I have also started working on making FAT accept command line options and patching multiple GBA ROM's at a time. Currently, it just forwards the command line input to the input file box. But patching GBA ROM's through the command line should be implemented soon as well. These features should hopefully all be implemented in the next version! Also, the new version will have GBA Flash Cart flashing support. Currently I'm investigating the Visoly USB linker protocol with two friends, Smileydude and mr_spiv. Hopefully that or part of it can be implemented in the next version as well. Also, I'm looking for a new GUI design as people have expressed complaints in the past about the current one. If anyone has any ideas about a new design, I would be extremely thankful if you could e-mail at costis@gbaemu.com about it. Thanks and expect a new version very soon and also thanks to Djammer for beta testing!!!

V7.0

It's been almost a month now without a new release! Anyway, this release contains full EEPROM patching (including the old libraries). ;) I orginally used GBAUtil's code for the older library EEPROM patching, but I changed some of it to adapt it to my code. I also made the GUI "fatter" and "shorter". :) Mech Platoon still doesn't work correctly, but I'll try to fix it after the GBADev.org competition is over. Zip file support is not yet implemented, but you can be sure that it will in the next version. Also, now the Browse buttons should work in all versions of Windows thanks to a piece of code from VBA.

V6.0

I added game header viewing and editing support in this version. It also tells you what type of save type (if any) each game uses, if they have multi-boot (not multi-ROM) support, and if they have enough FF's to have space for the multi pack file. The GUI is starting to get very long. You can expect a GUI change in the next version. Also, I find some mistakes in the 64kb EEPROM patches. Basically, 64kb EEPROM patching is supposed to be the same exact thing as 4kb EEPROM patching, instead of writing more bytes at a time. This will be fixed in the next version as it is not a major problem and 4kb EEPROM patching should be currently used for ALL EEPROM games. I am still trying to fix Mech Platoon, and hopefully the new version will successfully be able to EEPROM patch it correctly. And finally, have a Merry Christmas and a Happy New Year!
  
V5.0

This is another big release! This time I added 4kb and 64kb EEPROM patching support. The next version might contain automatic EEPROM size detection. Many thanks to DadyCool for explaining how EEPROM patches work and giving me sample code. Also, since the program now supports much more than intro removing, I am changing the name to Flash Advance Toolkit, or (F.A.T. :) :)). Many thanks to Guyfawkes for the new name!

V4.0

I added Multi-rom Patching Support to the program. The next version, which will hopefully come out soon will for sure contain 4kb and 64kb EEPROM patching support. For now, the program needs the ROMs it patches for multi-ROM support to have some space at the end of FF's. I might later change it so it also looks for 00's as well.
 
V3.0

This originally was just an Intro Remover, but due to popular demand I added on to it and it can now "trim" the FF's of ROMs to make them multi-romable. Very soon, I will add 4kb and 64kb EEPROM patching support. Also, I completely rewrote the GUI in C, so now a DLL is not needed and it shouldn't need any ocx controls or VB runtime files. :) :)

To shorten things down, here is basically what is new in this version:

- Complete change of user interface
- Complete rewrite of GUI code in C (Now the whole program is in C)
- Trimming FF's support

How to use it
-------------

1. Choose an input and an output file.
2. Either click on Automatically Remove Intro, Automatically Trim FF's or Automatically        Multi-ROM Patch.
3. If you did everything correctly and if there is an intro, there are FF's on the ROM, or    if there is enough space at the end to multi-ROM patch the ROM then it should reply       saying that everything was successful.

If you want to both remove an intro and trim the FF's from a ROM, then you have to them one at a time:

1. Choose an input and an output file.
2. Click on Automatically Remove Intro.
3. Change the input file to be the same as the output file.
4. Click on Automatically Trim FF's.

The same applies to all other double or even triple combinations.

Note: The input and output files can be the same. If they are, then the program will directly remove the intro or "trim" the FF's from the original input file.


Have fun!!!!

Costis