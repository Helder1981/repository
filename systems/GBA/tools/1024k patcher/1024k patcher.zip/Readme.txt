xul8t0r brings you:
1024kbit FLASH Patcher 1.3
http://haggar.emuunlim.com/fix/

This small program will patch some new FLASH 1024kbit games.
This program has been developed and tested using a ez-flash cart.


News:
1.3
- Fixed some more errors.

1.2
- Added choice of patching so it uses 64KByte saves or 128KByte.
- Fixed a small error.

1.1
- Added automatic value search.
- Added some error messages.

1.0
- First release.


How to use:
1. Open the program.
2. Choose if you want to use 64KByte saves or 128KByte saves.
3. Use file -> open or press Ctrl+O.
4. Choose the rom you want to patch.
5. Wait for a moment.
6. If the game uses FLASH 1024kbit
   some values should be filled in.
7. Use file -> save or press Ctrl+S.

REMEMBER TO TAKE BACKUPS OF YOUR FILES.

The only difference between the 64KByte save and the 128KByte
save is the identifier. Some carts and some flash software
likes to have the 64KByte type, since having 128KByte is a
waste since it doesn't support it.

Only way to check if you cart/software supports 128KByte
is to flash a game with 128KByte enabled. If it works
it's ok. If not, just use 64KByte.

It might not work with games that got intros.
Try to get clean versions of the rom if possible.

It might not work with games bigger then 16MB.
There isn't any games that are that big yet that
uses FLASH 1024kbit, though.

This program will NOT patch Pok�mon games.


If you want to do stuff manually, do this:
Optimize Value 3:
1. Uncheck the use "safe" location checkbox.
2. Open a file.
3. Input an optimized value 3 you know of.
4. Save the file.

Patch:
1. Uncheck the automatic search checkbox.
2. Open a file.
3. Fill in value 1, value 2 and value 3.
4. Save the file.

Search for values:
Use a hex editor or something and search for these hex values:
0x10700549
0x464C4153

When (or if) you get result(s), write down the adress and
convert it from hex to decimal. Use the Windows Calculator
in scientific mode or something like that.

If you get multiple results, then try these hex values instead:
0x1070054955200870
0x464C415348314D5F

The third value should be the start of a location where
there are empty space for 0x100 bytes of length. The end
of the rom is a safe location, but there are other ones
that are more optimal.

Known values for some games:
Super Mario Advance 4 (J)
Value 1: 939582
Value 2: 2507160
Value 3: Optimal: 4067680

Super Mario Advance 4 - Super Mario Bros 3 (E)
Value 1: 961326
Value 2: 3182188
Value 3: Optimal: 4742700

Super Mario Advance 4 - Super Mario Bros 3 (U)
Value 1: 945690
Value 2: 2505328
Value 3: Optimal: 4065840 Safe: 4194220

Card e-Reader (U)
Value 1: 277042
Value 2: 3892128
Value 3: Optimal: 7422500

Card e-Reader + (J)
Value 1: 343026
Value 2: 3448752
Value 3: Optimal: 7107920


If you know of games that use 1024kbit FLASH, but doesn't
get patched with this program mail me. If there are any
problems with the program then mail me. Do NOT mail me
and ask for roms.

Check the webpage for patch loactions for games that needs it
and program updates.

If you get a dll error please download the dll pack from the
webpage, or search for it on www.google.com or something.

Thanks to JustBurn for the help.

-eof-