extern void bytecpy(void *in_dst, const void *in_src, unsigned int length);
extern void byteclr(void *in_dst, unsigned int length);
extern int SaveData(u32 in_dst, const void *in_src, unsigned int length);
extern int byteverify(void *in_dst, const void *in_src, unsigned int length);
