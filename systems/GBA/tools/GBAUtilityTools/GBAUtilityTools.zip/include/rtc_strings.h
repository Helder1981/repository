extern const char Hoursofday[][3];
extern char day_of_week[7][4];
extern const char Months_short[][4];
extern const char Mins_secs[][3];
extern const char DaysinMonNum[][3];
extern const char YearsToCome[][5];
