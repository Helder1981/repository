dsmgba : by Ian Edmundson . Dos/Win32 v1.0-C++: October 2002
Please report any bugs to eddie01100@yahoo.co.uk
(you are free to use this file as you please)

This executable file was script generated from the GALT specification. Versions of this file can currently be found for the following platforms: 

	Java
	Linux (i386)
	Linux(mips r5900)
	Win32/Dos

See http://www.arcadenation.com for further details

usage: dsmgba filename output offset

	filename is name of gba binary
	output can be one of either ARM, or THUMB
	offset is the hex representation of the start address

Use > to redirect console output to a file. 
e.g. the following saves the output to a file named asmdump:

	dsmgba test.gba ARM 8000000 > asmdump

(NOTE: dsmgba marks the starting point of code generation for GALT-PS2) 






