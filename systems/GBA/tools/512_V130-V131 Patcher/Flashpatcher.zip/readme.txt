Hi there,

This is version 0.3 of my flash save patcher for Xtreme, EZ1 and XG1 users. Currently it deals only with roms with save type FLASH512_V130 or FLASH512_v131 - check a release list for which these are. If the rom is the wrong save type, it'll abort and tell you so.

To use the tool, run:
flash <unpatched rom> <patched rom>

It'll report success if it applied all changes. If the patcher reports that patching was successful and yet the game does not save, please let me know. If the patcher reports that not all chunks were applied, please let me know. In order to help you I will need the name, region and number of the rom you are using, and its CRC32 (you can get this with ClrMame or various other tools).

Contact me on ICQ# 10345149, MSN torne_wuff@hotmail.com or AIM TorneWuffpup, or send me a PM on emuboards; I am torne. Do not email me. You will be ignored.

Hope this helps someone; new versions will be available as and when possible. I will be adding support for other save types Real Soon so please be patient and don't bother me about it.

This tool is freeware; copy it if you want, but I would prefer if you linked back to http://whitefang.fitz.cam.ac.uk/gba/ instead as it'll be updated there. Update news..etc will be posted on Emuboards in the Xtreme forum.

Thanks,
Torne

Changelog:
v0.1 - Initial release
v0.2 - Fix incorrect assumption about FLASH_V131 code layout. Should work on Sword of Mana and some others now. Add more output so that you can tell me WHICH chunks it failed on.
v0.3 - Add support for FLASH_V130. Turns out I was working with the wrong hexdump all along, and V130 and V131 actually have exactly the same patch, byte for byte; thus, the program now accepts either type and works. =)