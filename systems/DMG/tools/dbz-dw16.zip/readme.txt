                           DGBMAX (Win) - Readme
                          -------------------------
                               (written by The Emperor)



  Content

    (1)  How does DGBMAX work ?    
    (2)  Hardware/Software Requirements
    (3)  Getting started
    (4)  The patch-system
    (5)  SRAM-Management
    (6)  The INI-Editor
    (7)  Description of the Options
    (8)  Other things you can do
    (9)  Linux & Wine                     NEW
    (10)  The DGBMAX-GB-Menu
    (11) The INI-Files
    (12) Submitting new ROMs
    (13) Some words about colorization
    (14) Contact/Updates/Bug reporting
    (15) Thanks/Credits
    (16) Legal stuff



(1) How does DGBMAX work ?
---------------------------

DGBMAX is a utility for flashing Doctor GB-carts. It combines the selected ROMs
into a  Multi-ROM-file. Unlike other software it uses it's own menu and not the
original GBPACK. The DGBMAX-menu doesn't scan the ROMs on the cart 'on the fly'
as GBPACK does.  Instead, it gets preprogrammed by the PC-part of DGBMAX.
Now  what advantages  does this have?  As  mentioned  in the  NFO-file,  DGBMAX
includes a large INI-file which has predefined colorsets for many games. DGBMAX
reads these palettes  from the  INI-file and  stores them in the MultiROM.  The
DGBMAX-menu then starts the game with the preprogrammed colorset. It also reads
an  alias-name  from the  INI-file which  replaces the old  name taken from the
header.
Another advantage is  that you can  store ROMs in  nearly every size as long as
they fit  into 32k-banks.  This means  that the ROM-size  must be a multiple of
32k. Some examples for this:
- 512k = 16 * 32k. This is a standard-size and does also work with the original
                   GBPACK
- 544k = 17 * 32k. This is a non-standard-size and only works with DGBMAX.
- 1536k (1.5 MB) = 48 * 32k. Non-standard, works only with DGBMAX.
- 1568k = 49 * 32k. Non-standard, works only with DGBMAX.
This  decreases the wasted space  on the flash-card as you  can strip  the ROMs
down to the smallest possible size,  so, for example, people with 16 mbit cards
are now able to actually get 2*8 Mbit games on their cards.
Yet another  advantage is that DGBMAX has full  control over SRAM - Management.
giveing it  the capability it to effectively reduce SRAM - usage.  For example,
ROMs which don't require a whole SRAM-bank will be able to share a single bank,
without interfering each other.


(2) Hardware/Software Requirements
-----------------------------------

You need  a computer that  is able to run  Windows 95 or above,  or Windows NT.
As it  is with any other  software, a faster  computer will run  DGBMAX faster.
Generally, any Pentium-class system should do it.
You can run DGBMAX at a resolution of 640x480, but believe me, it won't be fun.
So use  at least a resolution of  800x600. I also recommend 32k or more colors,
this looks much much better than 256 colors.
For Windows  NT you need to install the device - driver giveio.sys,  because NT
intercepts all port-accesses. Giveio is a workaround for this, you can download
it from the DGBMAX-webpage.


(3) Getting started
---------------------

Before  DGBMAX can access  your ROMs,  you must set  up searchdirs.  Do this by
selecting  the tab 'Searchdirs'.  Here you can add one or more searchdirs which
contain your ROMS. Press the 'Add searchdir'-button to do so.
You can then  switch back to the  ROM-selection and you will have all ROMs from
these dirs listed in the ROM-selection.
I also  recommend setting up the LPT - port for the  X-Changer,  because DGBMAX
autoscans all LPT - ports on  default.  This can cause  printer-problems as the
autoscan accesses all LPT-ports until an X-Changer is found.
DGBMAX does a realtime-scan for the X-Changer.  If you've set up your X-Changer
right, you just need to switch it on now. The LED-symbol at the top-left corner
should indicate that the X-Changer is on.  If you've inserted a cart, a picture
according to the cart-size will appear.
Once you've come that far, you can use DGBMAX for  creating MultiROMs. Just add
all ROMs you want to  have on the cart to the MultiROM-list,  either by double-
clicking them or by dropping them on the list. 
If you've finished selecting ROMs, press the flash-button and DGBMAX will flash
the MultiROM on the cart.


(4) The patch-system
--------------------

DGBMAX allows you to dynamically assign IPS- or GameGenie-patches to your ROMs.
You can do this by switching to the Patches - tab on the MultiROM - list.  Here
press the 'Add new patch'-button. Select wether it is an IPS- or a GG-patch and
enter the data accordingly (code or file). You can also drop an IPS-file on the
patches-list,  it will be automatically  added to the list.  The patches listed
here will always appear  if you select the ROM in the MultiROM - list, they are
assigned to the ROM.
If you want a patch to be applied when flashing, you can enable it now.

Some notes about the patches:
- GG-patches:
If you apply a GG-patch to a game, you can't switch it off on the gameboy.  For
example,  if you program unlimited lives for a game,  you won't be able to play
the game without unlimited lives until you  flash it again with unlimited lives
disabled.
DGBMAX accepts 6- and 9-digit-codes.  I recommend using  9-digit-codes if avai-
lable because  they give a more accurate description  on how to modify the ROM,
thus they avoid problems

- IPS-patches:
It  is  possible  that  there is  not  enough  space for an IPS - patch  due to
stripping. If this is the case, the ROM will be upsized, so the patch fits into
the ROM.  A good example for this is  Little Magic:  It has a stripped size  of
3 MBit.  If you  apply  the  capital - trainer to it,  it will  be  upsized  to
3.25 MBit because the trainer needs some space for it's code.
So don't be surprised if your ROMs get bigger if  you IPS-patch them, the patch
may needs some more space for the additional code/data.


(5) SRAM-Management
--------------------

DGBMAX has some unique functions for improving SRAM-Management. It allows ROMs
to share ROM - bank(s). Unfortunately there  are two ways how a  ROM can share
a ROM-bank which might cause a bit confusion. I will try to clear things up:

- DGBMAX can map two or more ROMs to the same SRAM-bank. This reduces SRAM-
  usage because (for example) two ROMs will use the same SRAM-bank. The big
  disadvantage of this is that these ROMs will overwrite each other's saves.
  This function will only be used if you enable RAM-sharing by double-clicking
  into the column 'share' of the ROM-selection.
  Be warned: Do so only if you fully understand what happens. This function
  may causes data-loss. Do not enable this for ROMs which store important data
  in SRAM.
- Unlike the previous method of RAM-sharing, DGBMAX can also assign different
  regions of a SRAM-bank to the ROMs. This has the advantage that the ROMs
  won't overwrite each other's saves, but is only available for ROMs that use
  less than 64kBit SRAM. (16kBit SRAM / MBC2: 2kBit SRAM). DGBMAX can fit up
  to two 16 kBit plus thirteen 2 kBit-ROMs into a SRAM-bank.
  You don't need to enable this function in any way, DGBMAX will automatically
  assign shared banks to ROMs which use less that 64k SRAM.

In order to make it easier to handle your saves, DGBMAX provides a SRAM-
manager. When you insert a cart, a list of ROMs using SRAM appears. Select a
ROM and press one of the transfer-buttons. DGBMAX will then prompt you for a
SRAM-file.
16 kBit  and  2 kBit SRAM - saves  will be  padded to full 64 kbit (8 kByte) to
maintain compatibility with other software.

The SRAM-Manager supports the following carts:

- Doctor GB-carts with DGBMAX-menu.
- Doctor GB-carts with GBPACK-menu.
- Original  game - carts.  It should also  work for the pocket - camera,  but I
  couldn't test it because I don't have a pocket-camera available. Any feedback
  on this would be very welcome.


(6) The INI-Editor
-------------------
If you don't  want to mess around  with the INI-file manually,  you can use the
INI-Editor if DGBMAX. Just right-click  a ROM and select 'Edit' from the popup-
menu, the editor will open.
If it is a CGB-ROM,  you can only edit the alias-name.  If it is a GB-only-ROM,
DGBMAX  allows you  to change the colors.  You can do this  either  by typing a
color-value,  as described in 'The INI-files',  or by moving the sliders on the
right.
When  everything fine,  press  'Write to USER.INI'  and  all modifications  are
saved.
Please note that DGBMAX does not check for ROMs with the same CRC/CC, it always
writes CRC  and CC to the INI.  This should work for 99% of the ROMs,  as there
aren't many ROMs with the same CRC.  So if there happens something strange (for
example  two times  the same name  for  a ROM),  check both INIs  and  add  the
Complement Check  if  necessary.   For  additional info on  this  info  look at
'The INI-files'.
Also  keep in mind that the colors are only previews.  They won't look the same
on the GBC, they are only supposed  to give you an idea how it will look on the
GB. For example, yellow usually doesn't look as intensive on the GBC as it does
on  your monitor.  And no,  it is not possible to use VGB - DOS,  or some other
emulator for preview, because they use another color-mapping.


(7) Description of the Options
-------------------------------

DGBMAX has various  options which allow you to configure DGBMAX for your needs.
To  go  to  the options,  press the options - button on  the right.  Here  is a
description of the options:

- X-Changer Options:
This is the hardware-setup for the X-Changer.  Select 'Auto' if you want DGBMAX
to scan for an X-Changer on all LPT-ports.  Please note that I do not recommend
this as this can cause trouble to  your printer.  If DGBMAX accesses a LPT-port
and  a  printer  attached to  this port  is printing,  it will usually kill the
print-job.
It is better to  specify the port address,  by selecting a default - port or by
entering the port-address into box for the user-specified port.
If you don't want DGBMAX to access any ports, select 'No X-Changer'.
DGBMAX performs a realtime-scan for  the X-Changer.  You can specify  how often
DGBMAX scans  for the X-Changer  by entering the Interval-time in  milliseconds
into the field 'Scan Interval'.  So if you want DGBMAX to scan once per second,
enter 1000 here.

- Interface Options
These options allow you to change the behaviour of the interface:
  - Language:
  You can select the interface-language here.
  - Highlight ROMs in list:
  If you enable this, DGBMAX will highlight ROMs in the  ROM-selection that are
  added to the Multi-ROM-list.
  - Autostrip ROMs when idle:
  Checking every ROM for it's stripped  size when DGBMAX starts  would take way
  too much time.  Instead of doing the  check at startup,  DGBMAX can check for
  the stripped sizes of the ROMs when the system is idle.
  Note that DGBMAX does not modify the ROM-files when stripping. It only stores
  the stripped  size and uses this  size when flashing. The strip - function of
  DGBMAX does not modify a single byte of your ROMs.
  Disable this option for slower machines.
  - Strip on default:
  If you add  a ROM to  the MultiROM-list, DGBMAX strips  it on default. If you
  you don't want DGBMAX to strip your ROMs  for whatever reason,  disable this.
  - Allow horizontal scrollbars:
  Disable this if you don't want horizontal scrollbars in the ROM-selection and
  in the MultiROM-list.
  - Register DMR-files
  You can save your ROM-lists to disk.  These files will have the extension DMR
  (DGBMAX MultiROM). If you enable this, DGBMAX will automatically register the
  extension DMR for DGBMAX. This tells windows to start DGBMAX when you double-
  click a DMR-file. Of course DGBMAX will automatically load the list.
  - Create backups
  If you enable this option, DGBMAX will automatically create a backup of a ROM
  if you permanently IPS-patch it.
  The  backups will  be saved in the sub - dir 'backup' which  is automatically
  created by DGBMAX.

- MultiROM-options
  These options change the look and behaviour of the gb-menu:
  - Use advanced menu
  If enabled,  you will get a menu if you  press start. This menu allows you to
  do  some  advanced  settings,  for  example  overriding the  default palette.
  If disabled, pressing start  will directly start  the game using the default-
  palette.
  - Text-Color and BG-color
  You can change the colors of the menu.  Enter the colors here the same way as
  you do in the INI-files.
  Pressing  Standard  restores  the  Standard - colors,  pressing  C64  gives a
  C64-style look.
  If you have some good ideas for menu-colors,  drop me a mail. I will add them
  in later versions.
 
- Emulator
  Pressing the right mouse-button in the ROM-selection  brings up a popup-menu.
  By using this popup-menu, you can start a ROM in an emulator.  Before you can
  do so, you must configure the emulator here.
  You can browse for the Emulator-EXE,  or can  can manually enter  it into the
  filename-box.
  - Enclose filename in quotes
  If enabled,  DGBMAX will put quotation marks around the ROM-filename.  Enable
  this for most Win-Emulators, except for SMYGB.
  Disable this for DOS-emulators.
  - Use 8.3 DOS-format
  DGBMAX can  convert the long ROM - filename  to the  DOS 8.3-format  (8 chars 
  filename, 3 chars for the file-extension). Enable this for DOS-emulators.

There is also one option that is only accessable via registry,  because I don't
think  anybody  will need this  often. I  actually included it because Harlekin
needs it for some strange reason:
The ROM - dumper will suggest a filename,  on default it  is the title from the
INI-file  (if available).  If you set the key  "ROMDumper_HeaderTitleAsDefault"
(you'll find  it under  "HKEY_LOCAL_MACHINE\Software\DGBMAX")  to 1,  the  ROM-
dumper will take the title from the ROM-Header.

If you want  to deinstall DGBMAX,  press 'Clear registry  and exit'.  This will
delete all registry-entries DGBMAX created, and will then terminate DGBMAX.

  
(8) Other things you can do
----------------------------

I think everythink important is explained now. This readme is very long anyway,
so here are some things you can do, without long description:

- Clicking on the header of a column will sort it's content
- You can - reorder/resize columns
          - autosize columns by double-clicking between the columns (like in
            MS Excel).
- It is possible to drop objects from the Windows Explorer:
  - the MultiROM-list and the flashcart-picture accept GB-ROMs.
  - the patches-list accepts IPS-patches.
  - the searchdirs-list accepts directories.
- Dropping a file from the -list or from the Explorer on the flashcart-
  picture will flash it as single-file, without menu.
- Press 'Rescan searchdirs' if you have added new ROMs while DGBMAX is running.
- Press 'Rescan INI-files' if you've made changes to the INI-files while DGBMAX
  is running.
- The Log-tab gives you a more detailed description of errors and warnings. 
  Look at this tab if something went wrong.
- Many object of DGBMAX have popup-menus.
- You can delete ROMs/patches by pressing delete on the keyboard.
- You can reorder the MultiROM-list and the patches-list (Drag&Drop).
- It is possible to convert Gangaboy-ROM-lists to DGBMAX. Just press
  'Open MultiROM-list' and select 'Gangaboy MultiROM-list' as file-type.


(9) Linux & Wine
------------------

It is possible to  use DGBMAX under Linux using Wine.  I've successfully tested
flashing  a 64 MBit - cart,  unfortunately flashing 16 MBit - carts only  gives
Write Errors (my guess is a timing-problem).
The main problem  was that the  tabs disappeared,  the autosize - function  set
their  height to 0.  To avoid this,  I added a Registry - entry that allows  to
manually set the height.
Start  DGBMAX  once  and  in  HKEY_LOCAL_MACHINE\Software\DGBMAX  the  new  key
'TabHeight'  is created.  Set this to  whatever fits  your system, 21  (15 hex)
worked for me.

The next problem is, as it's with Win NT/2000 too,  that Linux intercepts port-
accesses.  But unlike NT/2000,  you don't have to use nasty tricks for allowing
port-access,  you simply can add the adresses of  your printer port ($378/$278)
to the wine.ini.
Just add the following lines in the [ports]-section:
      read=0x378-0x37F
      write=0x378-0x37F
For  port 2  do  the  same respectively,  just  change  the  addresses  to  fit
$278-$27F. That's it !

Please note:  Wine - support is  far from  being perfect.  It is good luck that
flashing 64 MBit worked for me, this doesn't mean it works for you. Also, there
are many graphic glitches and for sure many more problems.


(10) The DGBMAX-GB-Menu
-----------------------  

The  GB-Menu should  be quite  self-explaining.  The game-selection works as it
used to be with GBPACK. The symbols next to the ROM also have the same meaning
as they have in GBPACK:

. ROM doesn't need SRAM
- ROM needs 64k SRAM
~ ROM needs 256k SRAM

In  addition to these symbols,  the menu will indicate ROMs which use 16k or 2k
(MBC2)  SRAM. A 16k - ROM will have small filled circle while a 2k - ROM has an
outlined circle.

If  you  press  the A - Button  you directly start the game  with the  colorset
specified in one of the INI-Files.
Pressing  start  opens  another   menu  with some options.   Here  is  a  short
description of these options:
- Start: Starts the selected game.
- Pal:  You  can  override the  default-palette  from  the INI- Files  with the
  colorsets  from GBPHACK.  Unfortunately, GBPHACK  has the colorsets  standard
  and  standard 2,  so  now there  are  the  colorsets  default,  standard  and
  standard 2 in the DGBMAX-menu which might  be a bit confusing.  I'll  explain
  it: The colorset default runs the  game with the predefined colorset from the
  INI-files.
  The colorsets  standard and standard 2 are the  colorsets from GBPHACK,  they
  can't be modified and are just some alternative colorsets like Aqua or Beach.
- PalOpt:  By using this  option you can  alter the  selected colorset.  If you
  want  an exact  description about  the PalOpt- settings, have a  look  at the
  readme of GBPHACK (Get it from xooming.to/gbphack).
- CPU: The CGB-cpu can run in single- or doublespeed-mode. With this option you
  can set the mode before starting the game. This is useful for some games like
  Faceball 2000. Faceball 2000 is a  3D-Game for the old GB and gets a smoother
  movement with  double-speed-mode.  I would say it  can be compared to running
  Quake on a faster machine.
  For other games this is just for fun, for example Super Mario 1 gets a really
  funky tune if running in doublespeed-mode (music is played twice as fast) !
- Help: Shows a help-screen.
- Exit: Exits the options-menu.
The options Pal and PalOpt are only available if you  run a non-color-game on a
CGB (think about it, this really does sense).


(11) The INI-Files   
-------------------

As DGBMAX  now got a color-editor,  this section isn't  really needed any more.
But for all those who want a bit background - info on how it works,  I'll leave
it here.

DGBMAX gets configured by two INI-Files:
- DGBMAX.INI.
  This is the INI-file with many predefined colorsets.  As it gets updated from
  time to time, you  should't put  your  colorsets into  this file because  you
  would have to do it  every time a new  version is released.  For this purpose
  we created the USER.INI:
- USER.INI
  This is the file where you should put your own colorsets. Any setting in this
  file  will  override the  setting from  DGBMAX.INI.  So you can put  your own
  colorets  in this file,  either if you want to create a colorset for game yet
  unsupported or you can override a  colorset from DGBMAX.INI if you don't like
  it.

An entry looks like this:
-------------------------------------------------------------------------
Alias
CRC: 0x????
BGPalette: #RRGGBB #RRGGBB #RRGGBB #RRGGBB
OBJPalette: #RRGGBB #RRGGBB #RRGGBB
WINPalette: #RRGGBB #RRGGBB #RRGGBB #RRGGBB
-------------------------------------------------------------------------
DGBMAX identifies the ROMs by comparing the CRC.  If it finds the ROM in one of
the INI-files it reads the  alias and writes it into the Multi-ROM.  This alias
appears  in the  ROM-selection after starting  the gameboy.  Then it  reads the
colors  from BGPalette,  OBJPalette and WINPalette  and writes  them  into  the
Multi-ROM.
Every color consists of three parts,  RR, GG and BB. This is a number from 0 to
31 (decimal)  which describes  how bright the  red, green  and blue part of the
color is.
If you  create an entry for  a color-rom you can leave  the palette-information
out as color-roms of course use their own colors.
An example (you may use this as a template for new colorsets):
-------------------------------------------------------------------------
After Burst
CRC: 0x23B3
BGPalette: #313131 #310000 #230000 #000000
OBJPalette: #000000 #002300 #001600
WINPalette: #313131 #232323 #161616 #000000
-------------------------------------------------------------------------
This tells  DGBMAX to check for the CRC 23B3 hex. If the  ROM has the CRC 23B3,
it writes the name 'After Burst' to the  Multi-ROM and uses the the four colors
#313131 (white), #310000 (bright red), #230000 (darker red) and #000000 (black)
as  Background-colors.  It  does  the  same  for  the  object-palette  and  the
window-palette.
Please note that  the window-palette  doesn't necessarily mean  the palette for
the  window.  I just  called it  that way because it is  the window-palette  in
many cases.  The gameboy-video-RAM can  hold two screens. The BG-palette is the
palette for the first screen,  the window-palette is the palette for the second
screen.  Many games use the  second screen for  the  window-palette.  But other
games  may use it  the other way  round or use  it  for  screen-buffering  (for
example  Street Fighter 2). In the second case,  bg-palette and windows-palette
have to be the same.  I can't give you  an universal solution for this,  so you
have to figure it out yourself.
For  the rare  case that  two ROMs  have  an  equal  CRC,  we  have  added  the
possibility  to add  the  complement checksum for  an exact identification.  An
entry  with  complement  checksum looks  like  the examples above,  but has the
complement checksum added next to the CRC:
CRC: 0x????/0x??
If you need an example,  look into the DGBMAX.INI and search for the entries
'Dragontail' and 'Motocross Maniacs'. These roms have equal CRCs, so they have
the complement checksum added.


(12) Submitting new ROMs
-------------------------

I have taken the color-sets  from VGB-MAX.  In many case these color-sets don't
fit 100%. So if you discover a colorset which looks strange,  do not wonder.  I
have  already  checked 180+ roms,  but I can't  check  all gameboy-games alone.
So I'd like you to help me.  You can send me new/corrected colorsets which will
be included in later versions of DGBMAX.INI.
If you
- checked a colorset,
- you created a colorset for a new game,
- you have a color-game (CRC !) which isn't in the INI-File,
Please  mail  it to  me  (the-emperor@gmx.de).  I only want complete entries as
described above (the example for After Burst).  For color-games,  you can leave
out the colors of course.


(13) Some words about colorization
-----------------------------------

Though this software is great for recoloring your old GB-games,  there are some
technical barriers which  this software can't overcome.  I will give you an ex-
planation about what is possible and what not:

- different  'scenes':  Recoloring an  old  game  is  like  recoloring  an  old
  B/W-movie  with the  difference that  you must use  the same  colors for  all
  scenes.  This means that  the colors  may perfectly match one scene, but they
  can be wrong for another scene. This is because DGBMAX only sets the palettes
  once,  before the  game  starts.  When  the  game  runs,  the  palette  stays 
  untouched.   Scenes   in  GB-games  are  usually  different  levels.  A  good
  example for this is Super Mario 2:  Using brown as  third background-color is
  good for most levels, but renders the water used in some levels brown.  Well,
  let's just say it is dirty water ;).
- palette changes during game: The GB uses other palettes than the CGB. This is
  obvious as the GB uses monochrome palettes which only describe the brightness
  and  the  CGB  uses  color-palettes.  If  you   use  DGBMAX  or  GBPHACK  the
  GB-games run in CGB-mode though they  are GB-Games.  The problem here is that
  palette-changes  of  GB-games  aren't  recognized  as  they  only  change the
  GB-palettes and not the CGB-palettes, of course.
  In most cases this doesn't  matter,  but some  games use  color-cycling which
  gets completely destroyed if you use the games in CGB-mode (which is the case
  if you use the original GBPACK, the enhanced GBPHACK-menu or the DGBMAX-menu)
- Object-palettes. The GB has two  (monochrome)  palettes for objects. So every
  object  may  be  assigned  to  one  of the two palettes using  an  attribute.
  The CGB on the  other hand knows  eight palettes for objects.  So  a game can
  assign one  of eight  palettes to  an object.  The attribute byte  looks like
  this: 76543210
           | | |
           | +-+-- CGB-palette selection: Bits 0-2=001: color palette 0
           |                              Bits 0-2=010: color palette 1
           |                              Bits 0-2=011: color palette 2
           |                              Bits 0-2=100: color palette 3
           |                              ... and so on
           |
           +------- GB-palette-selection: Bit 4=0     : Monochrome palette 0
                                          Bit 4=1     : Monochrome palette 1
  In CGB-mode, GB-palette-selection is disabled. A game may write a 0 or a 1 to
  Bit 4,  nothing  will  happen.  GB-games  don't  write  data to  CGB-palette-
  selection, so they can only use one object-palette.
  Again this doesn't matter in most cases. But some games get unplayable due to
  this,  for example  soccer-games (FIFA Soccer,  Sensible Soccer) because both
  teams  have the  same color.  You can't distinguish between your own and  the
  other team.
  The  only way to  fix this would  be a patch  for the ROM  which changes  the
  palette-selection-code.


(14) Contact/Updates/Bug reporting
-----------------------------------

If you have questions, suggestions or new colorsets you can mail me at:

    The-Emperor@gmx.de

In addition to that feel free to use the DGBMAX-Forum available at my website.

Please  keep  in mind  that DGBMAX  now  supports translations,  and  these are
usually  not done  by me,  for  obvious reasons.  Even if the readme is in some
other  language than english or  german, only use english or german if you mail
me.
If you post into the Forum, please only use english.

Get the latest version of DGBMAX and the DGBMAX.INI at XOOMING.TO/GAMEBOY

If you've found a bug,  start DGBMAX with the commandline-option /debuglevel 1.
A log - file will  be created  (log.txt),  send this log-file,  together with a
detailed (!) description of the bug, to the-emperor@gmx.de.
And think twice before you do so: It could also be a feature ;o).
If you want to help somehow, or you have a good suggestion, drop me a mail. Any
(constructive)  feedback is  always  welcome.  Just don't ask stupid questions,
especially don't ask me something about Pokemon.


(15) Thanks go to ...
----------------------

- Matt S.  for Beta-testing and for some very good ideas.
- Infect0r for writing DGBWIN and for some IPS-code.
- Bohlum Ng. He wrote the code for the new SRAM-sharing which allows MBC2-games
  to share a SRAM-Bank.
- The creators of the Gameboy Game Database. It is a great help.
- I almost forgot: Andy0 for the nice icon. (The green GB you click for
  starting DGBMAX).
- Everyone else who somehow helped.


(16) Legal stuff
-----------------

DGBMAX is freeware which means you can use/copy it without paying anything, but
it is not allowed to sell this program!
Like  any   other  free software  DGBMAX comes without  any warranty.  The only
thing I guarantee you is that DGBMAX takes up some space on your harddisk.
We (the  authors)  are not responsible for  any  data-loss  or  any hardware or
software - damage caused by this software.  You use  this software at  your own
risk !!!
We (the authors) don't have any of the ROMs mentioned in any file of this soft-
ware.  All information was taken from public sources.  So don't ask us for ROMs
and don't ask us where to find them. We will not respond to any mails regarding
this subject. It is not legal to use this  software with ROMs you don't own the 
original catridge for.