/=====================================================================\
|                                                                     |
|                         DirectEd Tile Editor                        |
|                                                                     |
|                                 v.997                               |
|                                                                     |
|                                1/15/01                              |
|                                                                     |
|                         Programmed by (wraith)                      |
|                          Ethereal Productions                       |
|                   http://donut.parodius.com/ethereal/               |
|                                                                     |
\=====================================================================/

                /==================================\
                |                                  |
                |              Changes             |
                |                                  |
                \==================================/

- Changes From version .996 to .997:
    o Custom palettes finally added! See 'Palette Sliders' below for
      more details.
    o Added support for ini files to determine what mode to start in. 
      DirectEd will look at the file extension of the first file 
      you open and compare it what mode you associated that extension with 
      in the ini. Thank Neil (you know, the Romhacking.com guy) for the 
      suggestion.
    o Also thank Neil for suggesting a tweak to the comparison feature.
      DirectEd now checks the file in chunks equal to the amount of bytes 
      per tile for the current viewing mode. See the instructions for 
      comparing files for more information.
    o Fixed a bug that popped up in v.996 due to my accidentally changing 
      a signed variable to an unsigned type. THis caused some 
      "unpredictable results" ( I always wanted to say that :P) depending 
      on exactly what version of windows you use. Regardless, the problem 
      is now rectified.

- Changes From version .995 to .996:
    o Recompiled under DirectX 5 SDK. Should see increased compatibility 
      under Windows NT 4.
    o Thanks to suggestions from Cowering, I've added the following:
        + Compare two files for Differences with the
          'C' key. DirectEd will jump straight to the 
          offset of the differences.
        + Based on file extension, DirectEd will start 
          up in the correct mode now.
        + Added Sleep(75) at the end of the main loop. 
          You should notice a slight decrease in keyboard 
          sensitivity ^^;
        + Should now display the full filename of the file 
          at the top. Extremely long filenames have the middle 
          truncated instead of the end.


----------------------------------------------------------------------------

                /==================================\
                |                                  |
                |          Introduction            |
                |                                  |
                \==================================/

Greetings. Thank you for falling in the 3% of the population that actually 
reads a readme before trying to bug the author about how to use a program. 

Anyway, this is my little program, known as DirectEd. What it is is a little 
program I wrote to demo my 1337 DirectX Programming skills (which means you 
need DirectX on your machine to run this). I developed this with the DirectX 5 
SDK, so you probably need DirectX 5 or better. The developement was on an Athlon 
750 Mhz processor with a Voodoo 3 board with 128 MB RAM and 16 MB of video RAM. 
If your system is different, your mileage may vary. (For the record, it runs a 
*little* bit choppily on my brother's PII 233 with 64 MB of RAM and a Voodoo 3 
Grapics Board). But, I've also heard that it runs on a P166 with only 32 MB of 
RAM (thanks Esperknight and Megaman X). So you can probably run it.

What this program does is edit tilesets of various console systems. Namely, it 
can edit monochrome graphics (1bpp graphics, used on various platforms), Gameboy, 
Nes, Virtual Boy, Neo Geo Pocket Color, Snes, Turbografx/PC Engine, Sega Master 
System, Game Gear graphics, Wonderswan Color, and even Sega Genesis graphics.

Anyway, the program runs fullscreen, which I know is pass�. But too bad. It does 
the job well enough for me. When you run the program, you will encounter an 
'Open File' dialog box. Just choose a ROM to Open to and away you go.After choosing 
a ROM, you will encounter a SECOND 'Open File' dialog. This is optional. It allows 
you to open a second file so that you can copy tiles from one ROM to another. More 
on that later.


       ========== SUPPORTED GRAPHIC MODES ===================
       ------------------------------------------------------
            - 1bpp (monochrome) mode
            - 2bpp (4 color)
                 - Gameboy/Snes
                 - Nes
                 - Virtual Boy
                 - Neo Geo Pocket Color
            - 3bpp (8 color)
                 - Snes*
            - 4bpp (16 color)
                 - Snes/PC Engine
                 - Master System/Gamegear/Wonderswan Color
                 - Sega Genesis/x68000
  
            * Not really a snes storage method. this is
              actually a form of compression.
       ------------------------------------------------------
       ======================================================

                /==================================\
                |                                  |
                |  Controlling this darned thing   |
                |                                  |
                \==================================/

Here's a list on how to control this thing:

KEYBOARD CONTROLS

UP ARROWN   - Scrolls up one row of tiles.
DOWN ARROW  - Scrolls Down one row of tiles.
LEFT ARROW  - Scrolls left one byte.
RIGHT ARROW - Scrolls right one byte.
Page Up     - Scrolls up one page.
Page Down   - Scrolls down one page
Home        - Returns to the beginning of the rom.
End         - Scrolls to the end of the rom.

C   - Only used if two files are opened. Compares the two files for any byte differences, 
      and jumps to the offset of the difference in both files. When the end of the file 
      is reached, it will return to the offset of the  first difference. This searches the 
      file in chunks equal in size to the amount bytes per tile in the current viewing mode. 
      More on this in the file comparing section.
G   - Toggles gridlines on/off.
M   - Switches between different graphics modes
S   - Saves the file currently selected.
TAB - Switches between which file is currently selected.
X   - Flips the edit box along the X axis.
Y   - Flips the edit box along the Y axis.

ALT + TAB - Minimizes the editor

THE MOUSE

You use the mouse to perform various editing
functions.

Left-Clicking:
  - Left-clicking in the palette box selects the color clicked as the current editing color. 
    This isn't the actual color it will become. The actual color it will be is determined by 
    the game as it runs.
  - Left-clicking in the Edit Box allows you to draw in it with the selected color.
  - Left-Clicking in the ROM Display area copies the tile you clicked on into the Edit Box, 
    replacing whatever was in there previously.
  - Left-clicking in the clipboard copies that tile of the clip board into the edit box, replacing 
    whatever was in there previously.

Right-Clicking:
  - Right-Clicking on the ROM Dislay area copies the contents of the Edit Box over whichever tile 
    in the ROM was right-clicked. The change does not actually take place until you click the 'S' 
    key to save the changes. * NOTE *: You can copy a tile into the edit box in one mode, and write 
    it back to the ROM in another. However, you need to be careful how you do this. More details to 
    be found below.
  - Right-Clicking on the Clipboard copies the contents of the Edit Nox over whichever tile in the 
    Clipboard was right-clicked.

                /==================================\
                |                                  |
                |             INI File             |
                |                                  |
                \==================================/

By placing directed.ini (a sample should have come in this zip) in the same directory as the 
DirectEd executable, you can now specify what mode DirectEd should start in based on what the 
extension of the first ROM file you open is.

Here's how it works. You place one entry per line only. Anything else will mess things up, and GOD 
help you then, because I certainly won't. The entry begins with the file extension you want (up to 
five characters--just in case they ever make something with abnormally long extensions), followed by 
a single space, followed by one of the following numbers:

1 - for 1bpp mode
2 - for Gameboy/Snes 2bpp mode
3 - for Nes 2bpp mode
4 - for Virtual Boy 2bpp mode
5 - for Neo Geo Pocket Color mode
6 - for Snes 3bpp mode
7 - for Snes/PC Engine 4bpp mode
8 - for SMS/Gamegear/Wonderswan Color
9 - for Genesis

for example, having the line:
foo 8
in your ini would tell DirectEd that if the first file you open has an extension of foo, it 
should start up in SMS 4bpp mode. You can have an unlimited amount of extensions in the ini 
file, so have fun configuring this to your own tastes.

*NOTE*
DirectEd defaults to 1bpp mode in any case where it can't find the ini file, or where it doesn't 
the a matching file extension in the ini.

                /==================================\
                |                                  |
                |         Palette Sliders          |
                |                                  |
                \==================================/

The three sliders on the right hand side of the screen control what color the current editing 
color is. They do not make any actual changes to what the color is in the ROM, they just change
what color is displayed in DirectEd. To change the actual color in the ROM, you'll need to 
find where in the ROM the palette data is stored, and alter that with a hex editor.

Anyway, each slider is linked to the Red, Green, or Blue intensity of the current color. It is 
in an RGB 888 format, so each value can have a value of 0-255. Sliding the slider down increases 
the intensity, sliding it up decreases the intensity.

                /==================================\
                |                                  |
                |          The Clipboard           |
                |                                  |
                \==================================/

The clipboard is a neat little feature I borrowed from TLayer, another bitchen' editor by SnowBro. 
It allows you to copy the contents of the Edit Box into a temporary storage area. You can then copy 
the tile back to the Edit Box and from there, you can edit it or insert it into the ROM. It's also 
ideal for piecing together larger pictures. It's just about big enough to do a 256x224 pixel 
(24 tiles x 20 tiles) title screen.

The really neat thing with the clipboard (and the Edit Box) is that it stores everything as a generic 
4bpp graphic. So, Essentially, it allows to copy a tile from one mode and put it back into the ROM in 
any other.

This is ideal, if say you really like Zelda 3's font (3bpp) and want to paste it into say ... Mega Man 7 
(4bpp). All you have to do is switch over to 3bpp mode, scroll to where the font is stored in the Zelda 3, 
left-click the font tile to copy it to the edit box, hit tab to switch over to the Mega Man 7 ROM, change 
the mode to Snes 4bpp, and paste it in over Mega Man 7's font by right-clicking the font tile you wish to 
replace. You may want to change the colors around to make it "fit" the palette of the original font. Besides 
that, there's nothing else to it. Except a word of CAUTION ... 

* WARNING *
You can easily copy from a low bit-depth to the same level bit-depth or higher. So, for instance, you can 
copy a 1bpp tile in 1bpp, Gameboy, Nes, Snes 3bpp, Snes 4bpp, SMS 4bpp, or Genesis 4bpp modes.

But you CAN'T copy from a higher bit depth to a lower one. Well, you can, but you lose color information. 
For instance. You have a Snes 3bpp tile in the edit box. You can copy it safely in 3bpp Mode (same bit 
depth), Snes 4bpp mode, SMS 4bpp, and Genesis 4bpp mode (all are higher depths than 3bpp). However, copying 
that tile in Nes , Gameboy (both are are 2bpp), or 1bpp mode WILL result in a loss of color information 
(as all of those are lower bit-depths than 3bpp).

                /==================================\
                |                                  |
                |          File Comparing          |
                |                                  |
                \==================================/

If you have two files open, you can compare them for any byte differences. This feature is pretty much 
useless unless the two files are pretty much different versions of the same game, or the same game with 
slight modifications. In any case, the files should be very similar or you're going to come up with many 
differences.

Anyway, pressing 'C' will compare the two roms for any differences. It examines the rom in chunks equal 
to the number of bytes per tile in the current viewing mode. So if you're in 1bpp mode, it will examine 
the rom in 8 Byte chunks. If you're in a 2bpp mode, it examines in 16 byte chunks. In a 3bpp mode, it 
examines using 24 byte chunks. 4bpp? You guessed it -- 32 byte chunks.

If it finds a difference, it will jump to the offset of the beginning of the chunk that contains the 
difference. pressing 'C' will take you to the next chunk with a difference. It will repeat like this 
until it reaches the end of the file. Then it will return you to the first difference. If no differences 
are found, youare returned to the beginning of the file.

Uses for this? Only one I can think of. You can use this to differentiate between two versions 
of the same ROM (for example, Killer Instinct 1.0 and Killer Instinct 1.1). It was actually Cowering 
(the Good* renaming utilities guy) who suggested this feature.


                /==================================\
                |                                  |
                |              Thanks              |
                |                                  |
                \==================================/

- Klarth: for explaining how NGPC and VB work.
- Neil: for his valuable input, support, and UI suggestions.
- Dave: for his support, and for being a hapless beta tester ;)
- CzarDragon, Megaman X, Esperknight, Naflign: for being the first people to try it out and actually
    tell me their opinion on it.
- Spinner 8: for constantly reminding me this should have run in a window.
- Cowering: For letting me know DIrectEd didn't like Win NT4. And for a bunch of suggestions :-)

Thanks for reading!
--(wraith)
15 January 2001

(wraith) takes no repsonsibilities whatsoever for any damages you may incur as a result of using this 
program. Use at your own risk!!!