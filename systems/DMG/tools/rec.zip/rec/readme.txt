	                 Rom Graphics Cracker  1.6a	
   			        by Willie Williams
		 			   aka
			            SS8Gogeta

			 E-Mail - ThaWilliest@hotmail.com


My sponser link, please support me, need to buy VC++ 5.0

http://www.commission-junction.com/track/track.dll?AID=43242&PID=245732&URL=http%
3A%2F%2Fwww%2Egamefever%2Ecom%2Fp%2F990917BA%2Easp

REVISIONS:
1.6a- Fixed an editing error.  After you loaded the last file
		before displaying graphics by double clicking the 
		name, it put an unwanted dot in the graphics area.

1.6 - Added Rom Editing support for all my supported modes!!

    - Added support for 1bpp
	
    - Added Load and Save palette support
  
    - Added Palette Editing

    - Added Snes Mode 7 interleaved graphic support ( make bitshift=2 )

    - Fixed Snes FX graphic support, It wasen't displaying the whole image

    - Changed display mode to 800x600x24 bit colors

    - Fixed the default palette, it didn't have the right colors, it had
	a lot of repeats

    - Added support for width in .tec files to go up to 256 pixels wide

    - Fixed the Rom loading routine, now you can keep loading Roms without
	the program crashing

1.5 - Added support for Virtual Boy graphics
    
    - Fixed Snes 256 color mode - something got erased for some reason

1.4 - Added row and column size control for the rom graphics.

    - Added support for Sega graphics

    - Added support for Snes Mode7 graphics

    - Added support for Snes FX graphics

1.3 - Fixed it so that it can work on any desktop resolution, but I advise 800x600x16 still.  
      If it still	doesn't work for some of you, E-mail me.
 
1.2 - Fixed it so that the scrollbar showes better on resolutions greater than 800x600.

1.1 - Fixed that nasty scroll bar error.  When you clicked it without having a ROM and 
	technique loaded, it crashed.

    - Fixed it so that it can work on other graphics cards that don't support 800x600 display 
	mode.

    - Fixed support for Windows 95.

1.0 - Initial release, (not much to say)


THE STORY:
Well, I made this tool basically just to learn C/C++, funny huh, most people would start
easy, I like to get right into it.  I knew JAVA a lot, so the conversion wasen't too bad.
For a QuickBASIC fanatic, I gotta say, C++ ain't bad, ain't bad at all.  I had a big problem 
finding a free compiler that would work right and I still do.  The one I'm using now, 
LCCWIN32, has a problem I can't figure out.  I can't assign the type float to any variables 
so I went through a lot just to get it to realize a stinking .5 ....

THE FUTURE:
I'll try to add another mode that counts by single bits, which will allow you to
create and test even more .tec files,  I didn't do this from the start cause I 
didn't see that it would cover all graphics modes possible, but its a little confusing. 
I will also try optimizing the speed more. In the far future I'll try working on 
rom decompression and recompression to go with this program,  bitmap decompression 
would be my first method, although it probably wont work but hay, its a start. 

PROBLEMS:
None now, got rid of all the bugs, at least, I hope so...

REQUIREMENTS:
- At least a 200mhz machine for a nice scrolling speed
- 8 mb ram
- DirectX 6.1 and above
- Desktop resolution of 800x600x16 and above


DISPLAYING GRAPHICS:
First you load a ROM, then you load a technique.  Once both of these are loaded, the rom 
graphics will be immediately displayed and you can scroll them.

PALETTE EDITING:
I've included a "default.pal" palette file with this program.  It has upto 1024 entries,
although I don't see the need in so many colors as of yet.  But you can edit the default
palette and save it under another file name if ya like.  The first 2 buttons shown in
the palette editing area are to move to a different entry, I allow up to 256 editable
entry's, like I said, no one needs to edit any further than that, and who would??  I 
also have other buttons that control the levels of Red, Green, And Blue within the
palette entry, up to 256 levels each.  To scroll numbers faster, just click the button
you want press rapitedly, then hold the space bar.  When you let go of space, the
screen gets updated, I do this for more convenient and faster scrolling.  Well that's
it for palette editing.

ROM EDITING:
I thought I'd never take this program this far, but I did.  I already knew how to do
it, so I figured I might as well make this tool worth more.  After you load a Rom, 
then load a .tec, at the bottom of the screen it says "MOUSE" and 4 arrow buttons are
below it.  All you have to do is choose which color the left mouse button will print,
and the color the right mouse button will print.  So now you can just click the 
graphics area to put the pixels you want.  Hold the mouse to keep putting dots 
rapitedly.  Its not the most advanced rom editing, but it does support bitshifting
and altering on how graphics are displayed.  I've given the user so much to alter
within this tool so I wont be taking rom editing any further than this, not just
yet anyway.

THE PROGRAM:

Controls:
Left arrow  - 	Bitshift left
Right arrow  -	Bitshift right
End -			Reset bitshift position
Up arrow -		Line up
Down arrow - 	Line down
Page Up - 		Page up
Page Down - 	Page down
ESC -			Magical button
Space bar -		Repeatedly pushes the last button you clicked on

If your like many computer users, there's something called a scrollbar and a mouse... :)

This program has something a little unique to other rom viewers, you can create and edit 
ways to view the rom!!  I looked and looked for a tool that can do this but couldn't find
any, and there arent many tools for Windows either.  These files have a .tec extention 
and I describe how to write them in each of my .tec files.  You have to use 3 digits 
then a comma then a space.  The number 1 would be 001, you get the picture.  I go by
single hex characters, so you count 1 character as 2. 

ex.
32 45 3A 4B AC  - 5 characters in a file in a hex representation
just split them and now they are
3 2 4 5 3 A 4 B A C - they are now 10 characters

each character represents 4 bits of graphic data and values  0 through F represent a pattern
0 - 0000
1 - 0001
2 - 0010
3 - 0011
4 - 0100
5 - 0101
6 - 0110
7 - 0111
8 - 1000
9 - 1001
A - 1010
B - 1011
C - 1100
D - 1101
E - 1011
F - 1111

0 - no dot here
1 - yes dot here

Snes graphics, 16 colors, have 4 bits per pixel, which just means you layer 4 hex values
over each other, get it?  Here's another example...

We'll read this as Snes rom graphics data..
Snes data uses the first hex as the first 4 bits of data and the second hex as the last 8
bits. It also layers the 1st hex with the 3rd, then with the 33rd then with the 35th for 
the first 4 bits and the 2nd with the 4th, then with the 34th, then with the 36th,

First get the first 4 bits of color data.

4F 39 2A 4B 49 23 A6 73 23 26 14 34 4A 49 39 09 1F 3F 2A 2B
|  |                                            |  |
1  3                                            33 35

This returns the first 4 bits of data..
4,3,1,3

Bit representation,
0 1 0 0 - 4
0 0 1 1 - 3
0 0 0 1 - 1
0 0 1 1 - 3
| | | |
| | | |
| | | |
| | | Color #7
| | Color #5
| Color #8
Color #0

Get it yet?

Now we read the next 4,

4F 39 2A 4B 49 23 A6 73 23 26 14 34 4A 49 39 09 1F 3F 2A 2B
 |  |                                            |  |
 2  4                                           34 36

This gives us the last 4 bits of data
F, 9, F, F

Bit representation,
1 1 1 1 - F
1 0 0 1 - 9
1 1 1 1 - F
1 1 1 1 - F
| | | |
| | | |
| | | |
| | | Color #15
| | Color #11
| Color #11
Color #15

Thats it...
now you get...
COL0,COL8,COL5,COL7,COL15,COL11,COL11,COL15

Keep doing this by making 8 by 8 squares read like a book.

Now to read the rom, you have to skip 4 hexes each read and after 8 increments, you do a 
big skip of 32, this is so you dont skip a hex value.  I still dont know if it will be 
okay to use the same hex twice though, the rom save routine I might write may not save 
it properly, though I think it will.

Well thats the tutoral on the .tec files, not too hard.  If you still have questions, E-Mail 
me and If I get around to it, I'll try to answer them.  Thank you very much and enjoy, and 
1 more thing, just in case by some wierd and catastropic occurance this program should happen 
to do anything destructive to your computer, by using it, you agree that I'm not responsible 
for the damage, I've tested it over and over and It shouldn't do anything wrong.

HELP:
Q: I don't see any graphics after loading a rom and loading a technique.
A: You need a desktop resolution of 800x600 and higher.  If you are using one that is higher 
	and it doesn't work, use 800x600.

Q: I still don't see any graphics,  whats up?
A: Try typing the filename and extension, or use a smaller directory for holding the
	rom and this program.

Q: The program doesn't load.
A: Be sure you using DirectX 6.1a and above.

Q: Can I have the source code,  you're not making any money off this.
A: No, well maybe if the price is right...

Thank You's
I'd like to thank the whole emulation community.  The emulator authors, the emulation site 
webmasters, the rom dumpers, and the users of these amazing programs.  I can only hope
that I get to do more for the emulation community.  I find it so amazing that this can be done.
I'd like to mainly thank all the rom hackers at Zophars Domain, www.zophar.net, for the help
in locating the documents explaining how rom graphics are stored in roms, and I'd like to
thank the authors of DEV-C++, MINGW32, GNUC, and  LCC-WIN32.  peace :)